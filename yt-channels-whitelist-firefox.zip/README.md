# Youtube whitelist channels (Firefox add-on)

**Summury:** This extension shows children only those videos that belong to whitelisted channels
 	
**Description:** I wrote this extension for my 6-year-old son to restrict his surfing on video content.
YouTube allows you to block unwanted videos, but it doesn't have the ability to make a white list of the channels you're allowed to watch. All video clips that do not belong to the channels on the white list are paused and hidden. To protect access to channel whitelisting management, a simple and unprotected method is used. The initial password is "1".


---
I am new to the JavaScript and this is my first experience. Tips, suggestions, comments and any feedback are welcome.
